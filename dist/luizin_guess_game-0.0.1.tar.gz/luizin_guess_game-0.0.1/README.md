# 📦 adicionando um Package ao pypi

### Tecnologias usadas

- Python
- Twine
- pip
- setup_tools
